@echo off
rem Открывает приложение в браузере по умолчанию. Node не нужен.
start "" "%~dp0index.html"
